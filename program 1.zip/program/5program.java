class program5
{
    public static void main(String[] args)
    {
    scanner sc= new scanner(system.in);
    System.out.prinln("input frist number");
    int num1=sc.nextint();
    system.out.println("input second number");
    int num2=sc.nextint();
    sc.close();
    int product=num1*num2;
    System.out.println("output:"+product);
}
}