class abcd
{
public static void main(String sarg[])
   {
          System.out.println("hello" + '\n' + "akshay randive");   
         
}
}