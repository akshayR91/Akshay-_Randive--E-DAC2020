class var2
{
    public static void main(String sarg[])
    {
    int a=74;
    int b=36;
    int c=a+b;

    System.out.println(c);
    }
}





