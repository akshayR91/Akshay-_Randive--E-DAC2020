import java.util.Scanner;
		 
public class program6
{
    public static void main(String args[])
    {
       int a, b, c;
       Scanner scan = new Scanner(System.in);
	   
       System.out.print("Input frist Numbers : ");
       a = scan.nextInt();
       System.out.print("Input second Numbers : ");
       b = scan.nextInt();
	   
       c = a + b;
       System.out.println("a+b = " +c);
	   
       c = a - b;
       System.out.println("a-b = " +c);
	   
       c = a * b;
       System.out.println("a*b = " +c);
	   
       c = a / b;
       System.out.println("a/b = " +c);

       c = a % b;
       System.out.println("a%b = " +c);
    }
}